/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 1996 - 2015  SEGGER Microcontroller GmbH & Co. KG       *
*                                                                    *
*        Internet: www.segger.com    Support:  support@segger.com    *
*                                                                    *
**********************************************************************

** emWin V5.28 - Graphical user interface for embedded applications **
emWin is protected by international copyright laws.   Knowledge of the
source code may not be used to write a similar product.  This file may
only  be used  in accordance  with  a license  and should  not be  re-
distributed in any way. We appreciate your understanding and fairness.
----------------------------------------------------------------------
File        : GUI_iType.h
Purpose     : Header file for the Monotype iType glue code.
---------------------------END-OF-HEADER------------------------------
*/
#ifndef  GUI_ITYPE_H
#define  GUI_ITYPE_H

#include "FS_object.h"
#include "math.h"
#include "GUI.h"
#include "GUI_iType.h"

#if defined(__cplusplus)
  extern "C" {             // Make sure we have C-declarations in C++ programs
#endif

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
//
// Specify the maximum heap used by iType.
//
#define ITYPE_MAX_BYTES_DEFAULT  800000L
//
// Some default values, most users will never have to change these.
//
#define ITYPE_DEFAULT_RENDER_STYLE  FS_MAP_GRAYMAP4     // Default rendering will be 4-bit per pixel anti-aliased glyphs
#define ITYPE_DEFAULT_BOLD          ITYPE_REGULAR_BOLD
#define ITYPE_ITALIC_ANGLE          15
#define ITYPE_BOLD_OVER_8PPEM       4000                // ~6% of em box (.06 * 65536)
#define ITYPE_BOLD_UNDER_8PPEM      6000                // Use ~9% for very small glyphs to make a difference
#define ITYPE_DEFAULT_EDGE_COLOR    GUI_BLUE
#define DEGREE_TO_RADIAN            0.01745329251944
//
// Glyph output styles, some of these are simply a mapping to iType
//
#define ITYPE_EMBOSSED           (FS_ULONG)0x00000001
#define ITYPE_ENGRAVED           (FS_ULONG)0x00000002
#define ITYPE_OUTLINED_FILLED    (FS_ULONG)0x00000004
#define ITYPE_OUTLINED_UNFILLED  (FS_ULONG)0x00000008
#define ITYPE_REGULAR_BOLD       (FS_ULONG)0x00000010
#define ITYPE_FRACT_BOLD         (FS_ULONG)0x00000020
#define ITYPE_NO_BOLD            (FS_ULONG)0x00000040
#define ITYPE_NO_EFFECT          (FS_ULONG)0x00000080
#define ITYPE_BITMAP             (FS_ULONG)0x00000100
#define ITYPE_GRAYMAP2           (FS_ULONG)0x00000200
#define ITYPE_GRAYMAP4           (FS_ULONG)0x00000400
#define ITYPE_EDGE_GRAYMAP2      (FS_ULONG)0x00000800
#define ITYPE_EDGE_GRAYMAP4      (FS_ULONG)0x00001000
#define ITYPE_SHADOW             (FS_ULONG)0x00002000
#define ITYPE_GLOW               (FS_ULONG)0x00004000
#define ITYPE_ITALIC             (FS_ULONG)0x00008000

/*********************************************************************
*
*       Types
*
**********************************************************************
*/
typedef struct {
  GUI_TTF_DATA * pTTF;                 // Pointer to GUI_TTF_DATA structure which contains location and size of font file
  U32            aImageTypeBuffer[4];  // Buffer for image type structure
  int            PixelHeight;          // Pixel height of new font. It means the height of the surrounding rectangle
                                       // between the glyphs 'g' anf 'f'. Please notice that it is not the distance
                                       // between two lines of text. With other words the value returned byGUI_GetFontSizeY()
                                       // is not identically with this value.
  int            FaceIndex;            // Some font files can contain more than one font face. In case of more than one face
                                       // this index specifies the zero based face index to be used to create the font. 
                                       // Usually 0. */
  void         * pUser;                // void pointer to be used by specific font engine
} GUI_ITYPE_CS;

typedef struct {
  FS_STATE  * pState;
  FS_SHORT    MapType;
  FS_LONG     RenderStyle;
  GUI_COLOR   EdgeColor;
  int         ShadowOffsetX;
  int         ShadowOffsetY;
} ITYPE_FONT_INFO;

/*********************************************************************
*
*       Prototypes
*
**********************************************************************
*/
int     GUI_ITYPE_CreateFont       (GUI_FONT * pFont, GUI_ITYPE_CS * pCS);
int     GUI_ITYPE_DeleteFont       (GUI_ITYPE_CS * pCS);
void    GUI_ITYPE_Done             (void);
int     GUI_ITYPE_GetFamilyName    (GUI_FONT * pFont, char * pBuffer, int NumBytes);
int     GUI_ITYPE_GetStyleName     (GUI_FONT * pFont, char * pBuffer, int NumBytes);
FS_LONG GUI_ITYPE_SetBoldPct       (GUI_FONT * pFont, GUI_ITYPE_CS * pCS, long pct);
FS_LONG GUI_ITYPE_SetCSMAdjustments(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, FS_FIXED SharpnessOffset, FS_FIXED SharpnessSlope, FS_FIXED ThicknessOffset, FS_FIXED ThicknessSlope);
void    GUI_ITYPE_SetEdgeColor     (GUI_FONT * pFont, GUI_ITYPE_CS * pCS, GUI_COLOR Color);
FS_LONG GUI_ITYPE_SetItalicAngle   (GUI_FONT * pFont, GUI_ITYPE_CS * pCS, int Skew);
long    GUI_ITYPE_SetOutlineOpacity(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, long Opacity);
long    GUI_ITYPE_SetOutlineWidth  (GUI_FONT * pFont, GUI_ITYPE_CS * pCS, unsigned short Width);
FS_LONG GUI_ITYPE_SetOutputStyle   (GUI_FONT * pFont, GUI_ITYPE_CS * pCS, long Type);
void    GUI_ITYPE_SetShadowOffset  (GUI_FONT * pFont, GUI_ITYPE_CS * pCS, int OffsetX, int OffsetY);

#if defined(__cplusplus)
  }
#endif

#endif  // GUI_ITYPE_H

/*************************** End of file ****************************/
