/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 1996 - 2015  SEGGER Microcontroller GmbH & Co. KG       *
*                                                                    *
*        Internet: www.segger.com    Support:  support@segger.com    *
*                                                                    *
**********************************************************************

** emWin V5.28 - Graphical user interface for embedded applications **
emWin is protected by international copyright laws.   Knowledge of the
source code may not be used to write a similar product.  This file may
only  be used  in accordance  with  a license  and should  not be  re-
distributed in any way. We appreciate your understanding and fairness.
----------------------------------------------------------------------
File        : GUI_iType.c
Purpose     : Glue code for the Monotype iType engine.
---------------------------END-OF-HEADER------------------------------
*/

#include "GUI_Private.h"
#include "fs_api.h"
#include "GUI_iType.h"

//#define DO_NOT_USE_LINKED_LIST    0
#define DO_USE_LINKED_LIST        1
#define USE_OF_LINKED_LIST DO_USE_LINKED_LIST

/*********************************************************************
*
*       Defines
*
**********************************************************************
*/
#define FAMILY_NAME 0
#define STYLE_NAME  1

/*********************************************************************
*
*       Types
*
**********************************************************************
*/
typedef struct {
  FS_STATE * pState;          // The iType FS_state
} ITYPE_CONTEXT;

struct STATES {
  const void    * pData;      // Pointer to iType font file in addressable memory area
  FS_ULONG        NumBytes;
  FS_STATE      * pState;
  FS_ULONG        Size;
  FS_SHORT        Index;
  struct STATES * pNext;
};

/*********************************************************************
*
*       Static data
*
**********************************************************************
*/
static ITYPE_CONTEXT   _iTypeContext;
static struct STATES * _pStatesList = 0;

/*********************************************************************
*
*       Static code
*
**********************************************************************
*/
#if USE_OF_LINKED_LIST == DO_USE_LINKED_LIST
/*********************************************************************
*
*       _SearchNode
*
* Function description
*   Search the linked list. Typical usage is to either supply both
*   pStates and pData OR pStateFS. Different usages would dictate if
*   we are looking to match a font or a state.
*
* Return value
*   Return STATES * if found, otherwise null.
*/
static struct STATES * _SearchNode(struct STATES * pStates, const void * pData, FS_ULONG NumBytes, FS_ULONG Size, FS_STATE * pStateFS, FS_SHORT Index) {
  while (pStates != NULL) {
    if (pStateFS != NULL) {
      if (pStates->pState == pStateFS) {
        return pStates;
      }
    } else {     
      if ((pStates->pData == pData) && (pStates->NumBytes == NumBytes) && (pStates->Size == Size) && (pStates->Index == Index)) {
        return pStates;
      }
    }
    pStates = pStates->pNext;
  }
  return NULL;
}

/*********************************************************************
*
*       _AppendNode
*
* Function description
*   Append a new STATES structure to the linked list
*/
static void _AppendNode(struct STATES * pStates, const void * pData, FS_ULONG NumBytes, FS_ULONG Size, FS_STATE * pStateFS, FS_SHORT Index) {
  while(pStates->pNext != NULL) {
    pStates = pStates->pNext;
  }
  pStates->pNext = (struct STATES *)malloc(sizeof(struct STATES));
  pStates->pNext->pData = pData;
  pStates->pNext->NumBytes = NumBytes;
  pStates->pNext->pState = pStateFS;
  pStates->pNext->Size = Size;
  pStates->pNext->Index = Index;
  pStates->pNext->pNext = NULL;
}

/*********************************************************************
*
*       _RemoveNode
*
* Function description
*   Remove new STATES structure to the linked list
*/
static void _RemoveNode(struct STATES * pStates, struct STATES * Node) {
  struct STATES * pStatesTemp;

  while (pStates->pNext != NULL) {
    if (pStates->pNext == Node) {
      pStatesTemp = pStates->pNext;
      pStates->pNext = pStates->pNext->pNext;
      free(pStatesTemp);
      return;
    }
    pStates = pStates->pNext;
  }
}
/*********************************************************************
*
*       _DeleteList
*
* Function description
*   Delete all of the nodes from the linked list
*/
static void _DeleteList(struct STATES * pStates) {
  struct STATES * pStatesTemp;

  while(pStates->pNext != NULL) {
    pStatesTemp = pStates->pNext->pNext;
    free(pStates->pNext);
    pStates->pNext = pStatesTemp;
  }
  free(pStates);
}
#endif

/*********************************************************************
*
*       _CheckInit
*
* Function description
*   Initializes iType font engine
*
* Return:
*   0 if sucsessful
*   1 if iType engine could not be initialized
*/
static int _CheckInit(void) {
  FS_ULONG Heap;

  //
  // Initialize library
  //
  if (!_iTypeContext.pState) {
    Heap = ITYPE_MAX_BYTES_DEFAULT;
    _iTypeContext.pState = malloc(sizeof(FS_STATE));
    if (!_iTypeContext.pState) {
      //
      // Could not allocate memory for state
      //
      return 1;
    }
    if (FS_init(_iTypeContext.pState, Heap)) {
      //
      // Could not initialize iType
      //
      free(_iTypeContext.pState);
      _iTypeContext.pState = 0;
      return 1;
    }
    #if USE_OF_LINKED_LIST == DO_USE_LINKED_LIST
      //
      // If using linked list to keep track of states
      //
      _pStatesList = (struct STATES *)malloc(sizeof(struct STATES));
      _pStatesList->pData    = 0;
      _pStatesList->NumBytes = 0;
      _pStatesList->pState    = _iTypeContext.pState;
      _pStatesList->pNext     = 0;
    #endif
  }
 return 0;
}

/*********************************************************************
*
*       _GetVertMetrics
*
* Function description (internal function)
*   Used to caluculate the vertical metrics of a font based on rendering a 'g' and 'M'.
*   Was origianlly part of GUI_Create_Font, but was needed elsewhere also.
*/
static FS_ULONG _GetVertMetrics(FS_STATE * pStateFS, GUI_ITYPE_CS * pCS, unsigned char * LHeight, unsigned char * CHeight) {
  FS_GLYPHMAP * pGlyphMap;
  FS_LONG       Error;

  Error = 0;
  pGlyphMap = FS_get_glyphmap(pStateFS, 'g', ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
  if (pGlyphMap) {
    *LHeight = pGlyphMap->hi_y + 1;
    FS_free_char(pStateFS, pGlyphMap);
  } else {
    return FS_error(((ITYPE_FONT_INFO *)pCS->pUser)->pState);
  }
  pGlyphMap = FS_get_glyphmap(pStateFS, 'M', ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
  if (pGlyphMap) {
    *CHeight = pGlyphMap->hi_y + 1;
    FS_free_char(pStateFS, pGlyphMap);
  } else {
    FS_error(((ITYPE_FONT_INFO *)pCS->pUser)->pState);
  }
  return Error;

}

/*********************************************************************
*
*       _RequestGlyph
*
* Function description
*   Draws a glyph (if DoRender == 1) and returns its width.
*/
static int _RequestGlyph(U16P c, unsigned DoRender) {
  GUI_ITYPE_CS * pCS;
  FS_GLYPHMAP  * pGlyphMap;
  FS_STATE     * pStateFS;
  FS_FIXED       s00, s01, s10, s11;
  FS_FIXED       dx, dy;
  FS_SHORT       Advance;
  FS_SHORT       Shadow;
  FS_SHORT       i_dx;
  FS_SHORT       i_dy;
  FS_LONG        RenderStyle;
  FS_LONG        Error;
  int            r;

  r = -1;
  //
  // Get object pointer
  //
  pCS      = (GUI_ITYPE_CS *)GUI_pContext->pAFont->p.pFontData;
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  //
  // This would be a very bad thing, not sure how we would ever get here...
  //
  if (!pStateFS) {
    return 1;
  }
  //
  // Do we need to set the scale?
  //
  Error = FS_get_scale(pStateFS, &s00, &s01, &s10, &s11);
  if ((FS_ULONG)s00 >> 16 != (FS_ULONG)pCS->PixelHeight) {
    Error = FS_set_scale(pStateFS, (FS_ULONG)pCS->PixelHeight << 16, 0, 0, (FS_ULONG)pCS->PixelHeight << 16);
  }
  //
  // From what we saw in the FreeType implementation, an Error here should return a value of 1
  //
  if (Error) {
    return 1;
  }
  if (DoRender) {
    //
    // We need the glypmap
    //
    pGlyphMap = FS_get_glyphmap(pStateFS, c, ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
    if (pGlyphMap) {
      if (pGlyphMap->bitsPerPixel == 1) {
        LCD_DrawBitmap     (GUI_pContext->DispPosX + pGlyphMap->lo_x, GUI_pContext->DispPosY - pGlyphMap->hi_y + GUI_pContext->pAFont->Baseline, pGlyphMap->width, pGlyphMap->height, 1, 1, pGlyphMap->bitsPerPixel, pGlyphMap->bpl, pGlyphMap->bits, GUI_pContext->LCD_pBkColorIndex);
      } else if (pGlyphMap->bitsPerPixel == 4) {
        GUI_AA__DrawCharAA4(GUI_pContext->DispPosX + pGlyphMap->lo_x, GUI_pContext->DispPosY - pGlyphMap->hi_y + GUI_pContext->pAFont->Baseline, pGlyphMap->width, pGlyphMap->height, pGlyphMap->bpl, (U8 const *)pGlyphMap->bits);
      } else if (pGlyphMap->bitsPerPixel == 2) {
        GUI_AA__DrawCharAA2(GUI_pContext->DispPosX + pGlyphMap->lo_x, GUI_pContext->DispPosY - pGlyphMap->hi_y + GUI_pContext->pAFont->Baseline, pGlyphMap->width, pGlyphMap->height, pGlyphMap->bpl, (U8 const *)pGlyphMap->bits);
      }
      if (pGlyphMap->i_dx == 0 && pGlyphMap->i_dy == 0) {
        r = (FS_ULONG)(pGlyphMap->dx + 0x8000) >> 16;
      } else {
        r = pGlyphMap->i_dx;
      }
      FS_free_char(pStateFS, pGlyphMap);
    } else {
      return r;
    }
  } else { 
    //
    // Although we would like to use FS_get_advance here for performance, we need to render for some special cases
    // Let's look for special cases where we may need to actually render the glyph to get the true width
    // Some of the special affects get treated a little differnet such as glow and drop shadow, even italic.
    //
    RenderStyle = ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle;
    if ( RenderStyle == ITYPE_GLOW || RenderStyle == ITYPE_SHADOW || RenderStyle == ITYPE_ITALIC || RenderStyle == ITYPE_OUTLINED_FILLED || RenderStyle == ITYPE_OUTLINED_UNFILLED) {
      if (RenderStyle == ITYPE_GLOW) {
        FS_set_flags(pStateFS, FLAGS_OUTLINED_SOFT);
        pGlyphMap = FS_get_glyphmap(pStateFS, c, ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
        pStateFS->flags &= ~FLAGS_OUTLINED_SOFT;
      } else if (RenderStyle == ITYPE_OUTLINED_FILLED) {
        FS_set_flags(pStateFS, FLAGS_OUTLINED_FILLED);
        pGlyphMap = FS_get_glyphmap(pStateFS, c, ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
        pStateFS->flags &= ~FLAGS_OUTLINED_FILLED;
      } else if (RenderStyle == ITYPE_OUTLINED_UNFILLED) {
        FS_set_flags(pStateFS, FLAGS_OUTLINED_UNFILLED);
        pGlyphMap = FS_get_glyphmap(pStateFS, c, ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
        pStateFS->flags &= ~FLAGS_OUTLINED_UNFILLED;
      } else {
        pGlyphMap = FS_get_glyphmap(pStateFS, c, ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
      }
      if (pGlyphMap == 0) {
        return r;
      } else {
        if (pGlyphMap->i_dx == 0 && pGlyphMap->i_dy == 0) {
          Advance = (FS_ULONG)(pGlyphMap->dx + 0x8000) >> 16;
        } else {
          Advance = pGlyphMap->i_dx;
        }
        //
        // Get the horizontal extent of the drop shadow to add to lenght calculation
        //
        if (((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle == ITYPE_SHADOW) {
          Shadow = ((ITYPE_FONT_INFO *)pCS->pUser)->ShadowOffsetX;
        } else {
          Shadow = 0;
        }
        //
        // Which is bigger the advance or actual inked
        //
        if (pGlyphMap->lo_x + pGlyphMap->width + Shadow > Advance) {
          r = pGlyphMap->lo_x + pGlyphMap->width + Shadow;
        } else {
          r = Advance;
        }
        FS_free_char(pStateFS, pGlyphMap);
      }
    } else {
      //
      // We can use the fast path here
      //
      Error = FS_get_advance(pStateFS, c, ((ITYPE_FONT_INFO *)pCS->pUser)->MapType, &i_dx, &i_dy, &dx, &dy);
      if (Error) {
        return r;
      } else {
        if (i_dx == 0 && i_dy == 0) {
          r = (FS_ULONG)(dx + 0x8000) >> 16;
        } else {
          r = i_dx;
        }
      }
    }
  }
  if (FS_error(pStateFS)) {
    return 1;
  }
  return r;
}

/*********************************************************************
*
*       _DispChar
*/
static void _DispChar(U16P c) {
  int xDist;

  xDist = _RequestGlyph(c, 1);
  if (xDist >= 0) {
    GUI_pContext->DispPosX += xDist;
  }
}

/*********************************************************************
*
*       _ClearLine
*
* Function description
*   If text should be rendered not in transparent mode first the whole line
*   needs to be cleared, because internally the characters always are drawn in
*   transparent mode to be sure, that also compound characters are drawn well.
*/
static void _ClearLine(const char  * s, int Len) {
  LCD_COLOR OldColor;
  int       xDist;
  int       yDist;
  int       xSize;
  int       xPos;
  int       yPos;
  U16       c;

  OldColor = GUI_GetColor();
  GUI_SetColor((GUI_pContext->TextMode & GUI_TM_REV) ? GUI_GetColor() : GUI_GetBkColor());
  xDist    = 0;
  yDist    = GUI_pContext->pAFont->YDist * GUI_pContext->pAFont->YMag;
  xPos     = GUI_pContext->DispPosX;
  yPos     = GUI_pContext->DispPosY;
  c        = 0;
  while (--Len >= 0) {
    c     = GUI_UC__GetCharCodeInc(&s);
    xSize = _RequestGlyph(c, 0);
    if (xSize >= 0) {
      xDist += xSize;
    }
  }
  LCD_FillRect(xPos, yPos, xPos + xDist - 1, yPos + yDist - 1);
  GUI_SetColor(OldColor);
}

/*********************************************************************
*
*       _DispLine
*
* Function description
*   Displays a string. If current text mode is not transparent, the
*   line is cleared before.
*/
static void _DispLine(const char * s, int Len) {
  const char   * sString;
  GUI_ITYPE_CS * pCS;
  GUI_COLOR      OldColor;
  FS_SHORT       RenderStyle;
  I16P           DispPosX;
  I16P           DispPosY;
  int            OldMode;
  int            Length;
  U16            Char;

  sString = s;
  Length  = Len;
  if (Len > 0) {
    //
    // Clear if not transparency mode has been selected
    //
    if (!(GUI_pContext->TextMode & (LCD_DRAWMODE_TRANS | LCD_DRAWMODE_XOR))) {
      _ClearLine(s, Len);
    }
    //
    // Draw characters always transparent
    //
    OldMode = GUI_pContext->TextMode;
    GUI_pContext->DrawMode |= GUI_DM_TRANS;
    //
    // Are we doing any special effects that need two passes?
    //
    pCS         = (GUI_ITYPE_CS *)GUI_pContext->pAFont->p.pFontData;
    RenderStyle = ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle;
    if (RenderStyle == ITYPE_GLOW || RenderStyle == ITYPE_SHADOW || RenderStyle == ITYPE_OUTLINED_FILLED) {
      OldColor = GUI_GetColor();
      //
      // We have to make two passes here, so we need to remember the initial pen position
      //
      DispPosX = GUI_pContext->DispPosX;
      DispPosY = GUI_pContext->DispPosY;
      GUI_SetColor(((ITYPE_FONT_INFO *)pCS->pUser)->EdgeColor);
      if (RenderStyle == ITYPE_GLOW) {
        FS_set_flags(((ITYPE_FONT_INFO *)pCS->pUser)->pState, FLAGS_OUTLINED_SOFT);
      }
      if (RenderStyle == ITYPE_OUTLINED_FILLED) {
        FS_set_flags(((ITYPE_FONT_INFO *)pCS->pUser)->pState, FLAGS_OUTLINED_FILLED);
      }
      if (RenderStyle == ITYPE_SHADOW) {
        GUI_pContext->DispPosX += ((ITYPE_FONT_INFO *)pCS->pUser)->ShadowOffsetX;
        GUI_pContext->DispPosY += ((ITYPE_FONT_INFO *)pCS->pUser)->ShadowOffsetY;
      }
      while (--Length >= 0) {
        Char = GUI_UC__GetCharCodeInc(&s);
        GUI_pContext->pAFont->pfDispChar(Char);
      }
      //
      // Now put things back the way they were for the second pass
      //
      GUI_SetColor(OldColor);
      if (RenderStyle == ITYPE_GLOW) {
        ((ITYPE_FONT_INFO *)pCS->pUser)->pState->flags &= ~FLAGS_OUTLINED_SOFT;
      }
      if (RenderStyle == ITYPE_OUTLINED_FILLED) {
        ((ITYPE_FONT_INFO *)pCS->pUser)->pState->flags &= ~FLAGS_OUTLINED_FILLED;
      }
      GUI_pContext->DispPosX = DispPosX;
      GUI_pContext->DispPosY = DispPosY;
    }
    //
    // We need to go back to the beginning and render the top layer
    //
    Length = Len;
    while (--Length >= 0) {
      Char = GUI_UC__GetCharCodeInc(&sString);
      GUI_pContext->pAFont->pfDispChar(Char);
    }
    GUI_pContext->DrawMode = OldMode;
  }
}

/*********************************************************************
*
*       _GetCharDistX
*/
#if (GUI_VERSION < 50801)
  static int _GetCharDistX(U16P c) {
    int xDist;

    xDist = _RequestGlyph(c, 0);
    return (xDist >= 0) ? xDist : 0;
  }
#else
  static int _GetCharDistX(U16P c, int * pSizeX) {
    #if 0
      GUI_ITYPE_CS * pCS;
      FS_GLYPHMAP  * pGlyphMap;
      FS_STATE     * pStateFS;
      int            xDist;
  
      pCS       = (GUI_ITYPE_CS *)GUI_pContext->pAFont->p.pFontData;
      pStateFS  = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
      pGlyphMap = FS_get_glyphmap(pStateFS, c, ((ITYPE_FONT_INFO *)pCS->pUser)->MapType);
      xDist     = _RequestGlyph(c, 0);
      xDist     = pGlyphMap->width;
      if (pSizeX) {
        *pSizeX = xDist;
      }
      return (xDist >= 0) ? xDist : 0;
    #else
      int xDist;

      xDist = _RequestGlyph(c, 0);
      if (pSizeX) {
        *pSizeX = xDist; 
      }
      return (xDist >= 0) ? xDist : 0;
    #endif
  }
#endif

/*********************************************************************
*
*       _GetFontInfo
*/
static void _GetFontInfo(const GUI_FONT * pFont, GUI_FONTINFO * pfi) {
  pfi->Baseline = pFont->Baseline;
  pfi->LHeight  = pFont->LHeight;
  pfi->CHeight  = pFont->CHeight;
  pfi->Flags    = GUI_FONTINFO_FLAG_PROP;
}

/*********************************************************************
*
*       _IsInFont
*/
static char _IsInFont(const GUI_FONT * pFont, U16 c) {
  GUI_ITYPE_CS * pCS;
  FS_STATE     * pStateFS;
  FS_ULONG       iType_glyph_index;
  
  GUI_USE_PARA(pFont);
  pCS      = (GUI_ITYPE_CS *)GUI_pContext->pAFont->p.pFontData;
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  iType_glyph_index = FS_map_char(pStateFS, c);
  return iType_glyph_index ? 1 : 0;
}

/*********************************************************************
*
*       _GetName
*/
static int _GetName(GUI_FONT * pFont, char * pBuffer, int NumBytes, int Index) {
  const char   * sName;
  GUI_ITYPE_CS * pCS;
  FS_USHORT      NumRecords;
  FS_USHORT      StringOff;
  FILECHAR     * sFilename;
  TTF_NAME       NameTable;
  FS_STATE     * pStateFS;
  FS_SHORT       StringLen;
  FS_ULONG       LenFS;
  FS_ULONG       i;
  FS_BYTE      * pRecords;
  FS_BYTE      * sString;
  FS_BYTE      * pTable;
  FS_LONG        Error;
  FS_LONG        j;
  int            Len;
  
  GUI_USE_PARA(pFont);
  sName     = NULL;
  sFilename = NULL;
  pCS       = (GUI_ITYPE_CS *)GUI_pContext->pAFont->p.pFontData;
  //
  // We may not have a state here if font was not created and no error checking was performed
  //
  if (!pCS) {
    return 1;
  }
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  //
  // This is a bad thing, not sure if we could ever really get here.
  // From what we saw in the FreeType implementation, should return 1 for failure.
  //
  if (!pStateFS) {
    return 1;
  }
  switch (Index) {
  case FAMILY_NAME:
    Error = FS_get_table_structure(pStateFS, TAG_name, &NameTable);
    if (Error) {
      return 1;
    }
    sName = NameTable.font_family_name;
    break;
  case STYLE_NAME:
    // 
    // This was lifted from get_abbreviated_name.
    // Would be much easier if the TTF_NAME structure also contained the style name.
    //
    sFilename = (FILECHAR *)SYS_MALLOC(FS_FILENAME_MAX);
    if (sFilename == NULL) {
      return 1;
    }
    pTable    = FS_get_table(pStateFS, TAG_name, TBL_EXTRACT, &LenFS);
    if (FS_error(pStateFS)) {
      free(sFilename);
      return 1;
    }
    NumRecords   = GET_xWORD((pTable + NAME_NUM_REC));     // Number of records to follow
    StringOff    = GET_xWORD((pTable + NAME_OFF_TO_STRS)); // offset to string storage
    pRecords     = pTable + NAME_NAMERECS;                 // The NameRecords
    sFilename[0] = 0;
    for (i = 0; i < NumRecords; i++, pRecords += NAME_SIZE_NAMEREC) {
      if ((GET_xWORD((pRecords + NAME_TAB_PLATID))) == MSFT_ENC  && (GET_xWORD((pRecords + NAME_TAB_LANGID))) == MSFT_US_ENGL) {
        sString = pTable + StringOff + GET_xWORD((pRecords + NAME_TAB_STROFF));
        StringLen = (FS_USHORT)GET_xWORD((pRecords + NAME_TAB_STRLEN)) >> 1;
        //
        // This is the style
        //
        if ((GET_xWORD((pRecords + NAME_TAB_NAMEID))) == 2) {
          //
          // Strings are in Unicode - 2 bytes per char
          //
          for (j = 0, sString++; j < StringLen; j++) {
            if (j < (MAX_FONT_FAMILY_NAME_LEN - 1)) {
              sFilename[j] = *sString;
            } else {
              break;
            }
            sString += 2;
          }
          sFilename[j] = 0;
          break;
        }
        if (sFilename[0]) {
          break;
        }
      }
    }
    FS_free_table(pStateFS, pTable);
    sName = sFilename; 
  }
  if (sName) {
    Len = strlen(sName);
    if (Len >= NumBytes) {
      Len = NumBytes - 1;
    }
    strncpy(pBuffer, sName, Len);
    *(pBuffer + Len) = 0;
  }
  //
  // This is only used for the style name
  //
  if (sFilename) {
    free(sFilename);
  }
  return 0;
}

/*********************************************************************
*
*       _APIList
*/
static const tGUI_ENC_APIList _APIList = {
  NULL,
  NULL,
  _DispLine
};

/*********************************************************************
*
*       Public code
*
**********************************************************************
*/
/*********************************************************************
*
*       GUI_ITYPE_SetShadowOffset
*
* Function description
*   Sets the horizontal and vertical offset for the drop shadow.
*   If this function is not called when using ITYPE_SHADOW effect, the
*   default values will be applied.
*/
void GUI_ITYPE_SetShadowOffset(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, int OffsetX, int OffsetY) {
  GUI_USE_PARA(pFont);
  ((ITYPE_FONT_INFO *)pCS->pUser)->ShadowOffsetX = OffsetX;
  ((ITYPE_FONT_INFO *)pCS->pUser)->ShadowOffsetY = OffsetY;
}

/*********************************************************************
*
*       GUI_ITYPE_SetBoldPct
*
* Function description
*   Sets the percentage of bold for pseudo-bold.
*   If this function is not called when using ITYPE_REGULAR_BOLD or 
*   ITYPE_FRACT_BOLD effects, the default value will be applied.
*/
FS_LONG GUI_ITYPE_SetBoldPct(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, long Pct) {
  FS_STATE * pStateFS;
  FS_FIXED   s00, s01, s10, s11;
  FS_LONG    Error;
  
  Error = 0;
  //
  // We may not have a state here if font was not created and no error checking was performed.
  //
  if (!pCS) {
    return 1;
  }
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  //
  // Check to see if this has already been set.
  //
  if (Pct == pStateFS->bold_pct) {
    return Error;
  }
  Error = FS_set_bold_pct(pStateFS, Pct);
  if (Error) {
    return Error;
  }
  //
  // Now we need to set the scale
  //
  FS_get_scale(pStateFS, &s00, &s01, &s10, &s11);
  Error = FS_set_scale(pStateFS, s00, s01, s10, s11);
  _GetVertMetrics(pStateFS, pCS, &pFont->LHeight, &pFont->CHeight);
  return Error;
}

/*********************************************************************
*
*       GUI_ITYPE_SetItalicAngle
*
* Function description
*   Sets the angle (in degrees) for pseudo italic text.  Typical value is 15.
*   The default value is defined as ITYPE_ITALIC_ANGLE in GUI_iType.h
*/
FS_LONG GUI_ITYPE_SetItalicAngle(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, int Skew) {
  FS_STATE * pStateFS;
  FS_FIXED   s00, s01, s10, s11;
  FS_LONG    Error;
  double     Adjustment;

  Adjustment = tan(Skew * DEGREE_TO_RADIAN);
  pStateFS   = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  FS_get_scale(pStateFS, &s00, &s01, &s10, &s11);
  Error      = FS_set_scale(pStateFS, s00, (FS_FIXED)((FS_ULONG)(((FS_ULONG)s00 >> 16) * Adjustment) << 16), s10, s11);
  _GetVertMetrics(pStateFS, pCS, &pFont->LHeight, &pFont->CHeight);
  return Error;
}

/*********************************************************************
*
*       GUI_ITYPE_SetOutputStyle
*
* Function Description
*   Sets the output style of the glyph, this includes bit depth and other
*   special effects.  It should be noted that some of the effects will result
*   in a change in the scale of the font, and possibly the vertical metrics.
*/
FS_LONG GUI_ITYPE_SetOutputStyle(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, long Type) {
  FS_STATE * pStateFS;
  FS_LONG    Error;

  Error = 0;
  //
  // We may not have a state here if font was not created and no error checking was performed.
  //
  if (!pCS) {
    return 1;
  }
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  switch (Type) {
  case ITYPE_EMBOSSED:
    Error = FS_set_flags(pStateFS, FLAGS_EMBOSSED);
    break;
  case ITYPE_ENGRAVED:
    Error = FS_set_flags(pStateFS, FLAGS_ENGRAVED);
    break;
  case ITYPE_OUTLINED_UNFILLED:
    Error = FS_set_flags(pStateFS, FLAGS_OUTLINED_UNFILLED);
    break;
  case ITYPE_OUTLINED_FILLED:
    ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle = ITYPE_OUTLINED_FILLED;
    break;
  case ITYPE_REGULAR_BOLD:
    FS_set_flags(pStateFS, FLAGS_FRACTBOLD_OFF);
    FS_set_flags(pStateFS, FLAGS_REGULARBOLD);
    if (pStateFS->bold_pct == 0) {               // If the bold percent has not been set set, set it to the default
      if (pStateFS->scale[0] > 0x80000) {
        Error = GUI_ITYPE_SetBoldPct(pFont, pCS, ITYPE_BOLD_OVER_8PPEM);
      } else {
        Error = GUI_ITYPE_SetBoldPct(pFont, pCS, ITYPE_BOLD_UNDER_8PPEM);
      }
    }
    break;
  case ITYPE_FRACT_BOLD:
    FS_set_flags(pStateFS, FLAGS_REGULARBOLD_OFF);
    FS_set_flags(pStateFS, FLAGS_FRACTBOLD);
    if (pStateFS->bold_pct == 0) {               // If the bold percent has not been set set, set it to the default
      if (pStateFS->scale[0] > 0x80000) {
        Error = GUI_ITYPE_SetBoldPct(pFont, pCS, ITYPE_BOLD_OVER_8PPEM);
      } else {
        Error = GUI_ITYPE_SetBoldPct(pFont, pCS, ITYPE_BOLD_UNDER_8PPEM);
      }
    }
    break;
  case ITYPE_NO_BOLD:
    FS_set_flags(pStateFS, FLAGS_REGULARBOLD_OFF);
    FS_set_flags(pStateFS, FLAGS_FRACTBOLD_OFF);
    Error = GUI_ITYPE_SetBoldPct(pFont, pCS, 0);
    break;
  case ITYPE_ITALIC:
    //
    // Let's look to see if an italic angle has already been set, similar to what we do for bold
    //
    if (pStateFS->scale[1] == 0) {
      Error = GUI_ITYPE_SetItalicAngle(pFont, pCS, ITYPE_ITALIC_ANGLE);
    }
    ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle = ITYPE_ITALIC;
    break;
  case ITYPE_GLOW:
    ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle = ITYPE_GLOW;
    break;
  case ITYPE_SHADOW:
    ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle = ITYPE_SHADOW;
    break;
  case ITYPE_NO_EFFECT:
    //
    // Set everything back to the default state
    //
    FS_set_flags(pStateFS, FLAGS_NO_EFFECT);
    ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle = ITYPE_NO_EFFECT;
    FS_set_outline_width(pStateFS, 1);
    FS_set_outline_opacity(pStateFS, 65536);
    break;
    //
    // Here we are just noting the map_type that will be used when rendering glyphs
    //
  case ITYPE_BITMAP:
    ((ITYPE_FONT_INFO *)pCS->pUser)->MapType = FS_MAP_BITMAP;
    break;
  case ITYPE_GRAYMAP2:
    ((ITYPE_FONT_INFO *)pCS->pUser)->MapType = FS_MAP_GRAYMAP2;
    break;
  case ITYPE_GRAYMAP4:
    ((ITYPE_FONT_INFO *)pCS->pUser)->MapType = FS_MAP_GRAYMAP4;
    break;
  case ITYPE_EDGE_GRAYMAP2:
    ((ITYPE_FONT_INFO *)pCS->pUser)->MapType = FS_MAP_EDGE_GRAYMAP2;
    break;
  case ITYPE_EDGE_GRAYMAP4:
    ((ITYPE_FONT_INFO *)pCS->pUser)->MapType = FS_MAP_EDGE_GRAYMAP4;
    break;
  default:
    break;
  }
  return Error;
}

/*********************************************************************
*
*       GUI_ITYPE_SetOutlineWidth
*
* Function description
*   Sets the width of the outline for use with the ITYPE_OUTLINED_FILLED and ITYPE_OUTLINED_UNFILLED
*   effects.  Default value without calling this fucntion is 1 pixel wide.
*/
long GUI_ITYPE_SetOutlineWidth(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, unsigned short Width) {
  FS_STATE * pStateFS;

  GUI_USE_PARA(pFont);
  //
  // We may not have a state here if font was not created and no error checking was performed.
  //
  if (!pCS) {
    return 1;
  }
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  return FS_set_outline_width(pStateFS, Width);
}

/*********************************************************************
*
*       GUI_ITYPE_SetOutlineOpacity
*
* Function description
*   This function set the opacity of an N-pixel outline. It has no effect on regular glyph images, only 
*   those with the outline effect. 
*
*   If not set, the default opacity is 65536 (1.0 in fixed point). The valid range for opacity is 0 - 655360 (0.0 - 10.0 in fixed point).
*
*   Opacity effectively defines the maximum gray level used for mixing the outline with the background. 
*   Note that the opacity value can exceed 1.0 (limit is 10.0). If the opacity is greater than 1.0 gray values are increased 
*   up to the limit imposed by the bit depth of the graymap requested. The allows a greater range of effects, particularly for the soft outline effect.
*
* Examples
*   Using 4-bit graymaps, an opacity of 49152 (0.75 in fixed point) will produce a maximum gray value of 11 instead of the normal 15. 
*   This gives 12 shades (including zero) of grayscale mixing with the background. An opacity of 13107 (0.2 in fixed point)will 
*   produce 4 levels of grayscale mixing. Values below 4370 (0.06668 in fixed point) will result a glyph image with no gray values.
*   Such opacity values are considered valid, but may not be useful.
*/
long GUI_ITYPE_SetOutlineOpacity(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, long Opacity) {
  FS_STATE * pStateFS;

  GUI_USE_PARA(pFont);
  //
  // We may not have a state here if font was not created and no error checking was performed
  //
  if (!pCS) {
    return 1;
  }
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  return FS_set_outline_opacity(pStateFS, Opacity);
}

/*********************************************************************
*
*       GUI_ITYPE_SetCSMAdjustments
*
* Function description
*   Allows end-user tuning of the CSM adjustment values for Edge(TM) rendering
*/
FS_LONG GUI_ITYPE_SetCSMAdjustments(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, FS_FIXED SharpnessOffset, FS_FIXED SharpnessSlope, FS_FIXED ThicknessOffset, FS_FIXED ThicknessSlope) {
  FS_STATE * pStateFS;
  
  GUI_USE_PARA(pFont);
  //
  // We may not have a state here if font was not created and no error checking was performed
  //
  if (!pCS) {
    return 1;
  }
  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  return FS_set_csm_adjustments(pStateFS, SharpnessOffset, SharpnessSlope, ThicknessOffset, ThicknessSlope);
}

/*********************************************************************
*
*       GUI_ITYPE_SetEdgeColor
*
* Function description
*   Set the color for edge-specific special effects such as ITYPE_OUTLINED_FILLED etc...
*   The default value is set as ITYPE_DEFAULT_EDGE_COLOR to ensure that something 
*   shows up assuming the default text color is black.  This default can be changed by
*   the user in GUI_iType.h
*/
void GUI_ITYPE_SetEdgeColor(GUI_FONT * pFont, GUI_ITYPE_CS * pCS, GUI_COLOR Color) {
  GUI_USE_PARA(pFont);
  ((ITYPE_FONT_INFO *)pCS->pUser)->EdgeColor = Color;
}

/*********************************************************************
*
*       GUI_ITYPE_DeleteFont
*
* Function description
*   End the state associated with a GUI_ITYPE_CS.  Does nothing with the GUI_ITYPE_CS
*   other than to set the usrPtr (which holds the state pointer) to zero.
*
* Parameters
*   pCS - Pointer to a GUI_ITYPE_CS structure which contains information about the TrueType font.
*
* Return value
*   Need to figure out what the return value should be.
*/
int GUI_ITYPE_DeleteFont(GUI_ITYPE_CS * pCS) {
  #if USE_OF_LINKED_LIST == DO_USE_LINKED_LIST
    struct STATES * Node;
  #endif
  FS_STATE * pStateFS;
  FS_LONG    Error;

  pStateFS = ((ITYPE_FONT_INFO *)pCS->pUser)->pState;
  FS_delete_font(pStateFS, pStateFS->cur_lfnt->name);
  //
  // Delete the client
  //
  Error = FS_end_client(pStateFS);
  #if USE_OF_LINKED_LIST == DO_USE_LINKED_LIST  
    //
    // Now remove this state from the linked list.
    //
    Node = _SearchNode(_pStatesList, 0, 0, 0, pStateFS, 0);
    _RemoveNode(_pStatesList, Node);
  #endif
  //
  // Set state pointer in GUI_ITYPE_CS to NULL.
  //
  pCS->pUser = 0;
  return Error;
}

/*********************************************************************
*
*       GUI_ITYPE_CreateFont
*
* Function description
*   Creates a new GUI_FONT object by a given TTF font file available in memory.
*
* Parameters
*   pFont - Pointer to a GUI_FONT structure to be initialized by this function.
*   pCS   - Pointer to a GUI_ITYPE_CS structure which contains information about 
*           file location, file size, pixel size and face index.
*/
int GUI_ITYPE_CreateFont(GUI_FONT * pFont, GUI_ITYPE_CS * pCS) {
  #if USE_OF_LINKED_LIST == DO_USE_LINKED_LIST
    struct STATES * pHead;
    struct STATES * pNode;
  #endif
  FsAscDescLeadSource   AscSource;
  FILECHAR              acName[FS_FILENAME_MAX] = { 0 };
  FS_STATE            * pStateFS;
  FS_FIXED              Ascender;
  FS_FIXED              Descender;
  FS_FIXED              Leading;
  FS_BYTE             * iTypeFaceId;
  FS_LONG               Error;

  pCS->pUser = malloc(sizeof(ITYPE_FONT_INFO));
  //
  // Let's set the default output to 4-bit graymaps
  //
  ((ITYPE_FONT_INFO *)pCS->pUser)->MapType       = ITYPE_DEFAULT_RENDER_STYLE;
  ((ITYPE_FONT_INFO *)pCS->pUser)->RenderStyle   = ITYPE_NO_EFFECT;
  //
  // Set the default edge color to blue, at least it will show up on a white or black background
  // if the user forgets to set a specific color
  //
  ((ITYPE_FONT_INFO *)pCS->pUser)->EdgeColor     = ITYPE_DEFAULT_EDGE_COLOR;
  ((ITYPE_FONT_INFO *)pCS->pUser)->ShadowOffsetX = 1;
  ((ITYPE_FONT_INFO *)pCS->pUser)->ShadowOffsetY = 1;
  //
  // Check initialization
  //
  if (_CheckInit())
    return 1;
  //
  // Select the currently created font
  //
  GUI_SetFont(pFont);
  #if USE_OF_LINKED_LIST == DO_USE_LINKED_LIST  // If using linked list to keep track of states
    //
    // Do we already have a state for this font?
    //
    pHead = _pStatesList;
    pNode = _SearchNode(pHead, pCS->pTTF->pData, pCS->pTTF->NumBytes, pCS->PixelHeight, 0, pCS->FaceIndex);
    if (!pNode) {
      pStateFS = FS_new_client(_iTypeContext.pState, 0);
    } else {
      return 0;
    }
  #else
    pStateFS = FS_new_client(_iTypeContext.pState, 0);
  #endif
  iTypeFaceId = (FS_BYTE *)pCS->pTTF->pData;
  Error = FS_load_font(pStateFS, 0, iTypeFaceId, pCS->FaceIndex, FS_FILENAME_MAX, acName);
  if (Error) {
    FS_end_client(pStateFS);
    return 1;
  }
  Error = FS_set_font(pStateFS, acName);
  if (Error) {
    FS_end_client(pStateFS);
    return 1;
  }
  Error = FS_set_scale(pStateFS, (FS_ULONG)pCS->PixelHeight << 16, 0, 0, (FS_ULONG)pCS->PixelHeight << 16);
  if (Error) {
    FS_end_client(pStateFS);
    return 1;
  }
  Error = FS_set_cmap(pStateFS, 3, 1);
  if (Error) {
    //
    // Try 3, 10 instead
    //
    Error = FS_set_cmap(pStateFS, 3, 10);
  }
  if (Error) {
    FS_end_client(pStateFS);
    return 1;
  }
  Error = FS_get_ascender_descender_leading(pStateFS, &Ascender, &Descender, &Leading, &AscSource);
  if (Error) {
    FS_end_client(pStateFS);
    return 1;
  }
  //
  // Now stuff the state into the font object
  //
  ((ITYPE_FONT_INFO *)pCS->pUser)->pState = pStateFS;
  pFont->XMag = 1;
  pFont->YMag = 1;
  //
  // Set function pointers
  //
  pFont->p.pFontData    = pCS;
  pFont->pfDispChar     = _DispChar;
  pFont->pfGetCharDistX = _GetCharDistX;
  pFont->pfGetFontInfo  = _GetFontInfo;
  pFont->pfIsInFont     = _IsInFont;
  pFont->pafEncode      = &_APIList;
  //
  // Calculate baseline and vertical size
  //
  pFont->Baseline = ((FS_ULONG)(Ascender +0x8000) >> 16);
  pFont->YSize = pFont->Baseline + ((FS_ULONG)(Descender + /*Leading*/ + 0x8000) >> 16) + 2;  // We (+) here where FT would (-), sign convention
  pFont->YDist = pFont->YSize;
  _GetVertMetrics(pStateFS, pCS, &pFont->LHeight, &pFont->CHeight);
  //
  // If using linked list to keep track of states
  //
  #if USE_OF_LINKED_LIST == DO_USE_LINKED_LIST
    pHead = _pStatesList;
    _AppendNode(pHead, pCS->pTTF->pData, pCS->pTTF->NumBytes, pCS->PixelHeight, pStateFS, pCS->FaceIndex);
  #endif
  return 0;
}

/*********************************************************************
*
*       GUI_ITYPE_GetFamilyName
*/
int GUI_ITYPE_GetFamilyName(GUI_FONT * pFont, char * pBuffer, int NumBytes) {
  return _GetName(pFont, pBuffer, NumBytes, FAMILY_NAME);
}

/*********************************************************************
*
*       GUI_ITYPE_GetStyleName
*/
int GUI_ITYPE_GetStyleName(GUI_FONT * pFont, char * pBuffer, int NumBytes) {
  return _GetName(pFont, pBuffer, NumBytes, STYLE_NAME);
}

/*********************************************************************
*
*       GUI_ITYPE_Done
*
* Function description
*   Will close all iType clients, free the initial state and purge
*   the linked list of STATES objects.
*/
void GUI_ITYPE_Done(void) {
  //
  // Shut down iType and free the FS_STATE
  //
  if (_iTypeContext.pState)
    FS_exit(_iTypeContext.pState);
  free(_iTypeContext.pState);
  //
  // Clear the linked list of states
  //
  #if (USE_OF_LINKED_LIST == DO_USE_LINKED_LIST)
    _DeleteList(_pStatesList);
    free(_pStatesList);
  #endif
}

/*************************** End of file ****************************/
